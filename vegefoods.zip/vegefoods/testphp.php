
<?php/*
include_once("config.php");
 
//getting id from url

 
//selecting data associated with this particular id
$result = mysqli_query($mysqli, "SELECT * FROM company_profile WHERE ind_name='{$_SESSION['name']}'");
if ($result) { // if user exists
 
 }
while($res = mysqli_fetch_array($result))
{

    $s=$res['image'];
  
}
?>