<html>
<head>
    <title>Add Data</title>
</head>

<body>
<?php
//including the database connection file
include_once("config.php");
if(isset($_POST['submit'])) {   
    $name = mysqli_real_escape_string($mysqli, $_POST['name']);
    $id = mysqli_real_escape_string($mysqli, $_POST['id']);
    $emailc = mysqli_real_escape_string($mysqli, $_POST['emailc']);
    $email = mysqli_real_escape_string($mysqli, $_POST['email']);
    $sub = mysqli_real_escape_string($mysqli, $_POST['sub']);
    $mess = mysqli_real_escape_string($mysqli, $_POST['mess']);
        
    // checking empty fields
    if(empty($name) || empty($emailc) ) {
                
        if(empty($name)) {
            echo "<font color='red'>Name field is empty.</font><br/>";
        }
        
        if(empty($emailc)) {
            echo "<font color='red'>Age field is empty.</font><br/>";
        }
     
        
        
        
    } else { 
        // if all the fields are filled (not empty) 
            
        //insert data to database   
        $result = mysqli_query($mysqli, "INSERT INTO send_message(ind_name,name,email,subject,message) VALUES('$id','$name','$email','$sub','$mess')");
        
        header('location: tea-industry.php');
    }
}
?> 
</body>
</html>