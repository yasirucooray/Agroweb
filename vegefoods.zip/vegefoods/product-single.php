
<?php
// including the database connection file
include_once("config.php");
include_once 'config2.php'; 
$result1 = mysqli_query($mysqli, "SELECT * FROM shop ORDER BY id DESC limit 4 "); 
if(isset($_POST['update']))
{    
    $id = $_POST['id'];
    
    $name=$_POST['name'];
    $age=$_POST['age'];
 
    // checking empty fields
    if(empty($name) || empty($age) ) {            
        if(empty($name)) {
            echo "<font color='red'>Name field is empty.</font><br/>";
        }
        
        if(empty($age)) {
            echo "<font color='red'>Age field is empty.</font><br/>";
        }
        
               
    } else {    
        //updating the table
        $result = mysqli_query($mysqli, "UPDATE shop SET name='$name',post='$age' WHERE id=$id");
        
        //redirectig to the display page. In our case, it is index.php
        header("Location: shop.php");
    }
}
?>
<?php 
  session_start(); 

  if (!isset($_SESSION['username'])) {
  	$_SESSION['msg'] = "You must log in first";
  	header('location: login.php');
  }
  if (isset($_GET['logout'])) {
  	session_destroy();
  	unset($_SESSION['username']);
  	header("location: login.php");
  }
?>

<!DOCTYPE html>
<html lang="en">
  <head>
  <title>AgroWeb</title>  
        <link rel="shortcut icon" type="images/png" href="images/local3.png">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    <link href="https://fonts.googleapis.com/css?family=Poppins:200,300,400,500,600,700,800&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Lora:400,400i,700,700i&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Amatic+SC:400,700&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="css/open-iconic-bootstrap.min.css">
    <link rel="stylesheet" href="css/animate.css">
    
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">

    <link rel="stylesheet" href="css/aos.css">

    <link rel="stylesheet" href="css/ionicons.min.css">

    <link rel="stylesheet" href="css/bootstrap-datepicker.css">
    <link rel="stylesheet" href="css/jquery.timepicker.css">

    
    <link rel="stylesheet" href="css/flaticon.css">
    <link rel="stylesheet" href="css/icomoon.css">
    <link rel="stylesheet" href="css/style.css">
  </head>
  <body class="goto-here">
 
  <nav class="navbar navbar-expand-lg navbar-dark ftco_navbar bg-dark ftco-navbar-light" id="ftco-navbar">
	    <div class="container">
      <a class="navbar-brand" href="index.html"><img src="images/new2.png"  width="260" height="100"></a>
	      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#ftco-nav" aria-controls="ftco-nav" aria-expanded="false" aria-label="Toggle navigation">
	        <span class="oi oi-menu"></span> Menu
	      </button>

	      <div class="collapse navbar-collapse" id="ftco-nav">
	        <ul class="navbar-nav ml-auto">
	          <li class="nav-item active"><a href="index.php" class="nav-link">Home</a></li>
	          <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" id="dropdown04" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Category</a>
              <div class="dropdown-menu" aria-labelledby="dropdown04">
              	<a class="dropdown-item" href="Tea-industry.php">TEA</a>
              	<a class="dropdown-item" href="rubber-industry.php">RUBBER</a>
                <a class="dropdown-item" href="cinnamon-industry.php">CINNOMEN</a>
   			</div>
            </li>
	          <li class="nav-item"><a href="user-map.php" class="nav-link">Map</a></li>
			  <li class="nav-item"><a href="blog.php" class="nav-link">Blog</a></li>
			  <li class="nav-item dropdown">
			  <a class="nav-link dropdown-toggle" href="#" id="dropdown05" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Fcilities</a>
              <div class="dropdown-menu" aria-labelledby="dropdown05">
              	<a class="dropdown-item" href="news.php">News</a>
              	<a class="dropdown-item" href="new-techno.php">New Technology</a>
                <a class="dropdown-item" href="solution.php">Solutions</a>
   
              </div>
			  </li>
			  <li class="nav-item"><a href="shop.php" class="nav-link">Shop</a></li>
              
			  <li class="nav-item"><a href="user-aboutus.php" class="nav-link">About-Us</a></li>
			  <li class="nav-item"><a href="contact.php" class="nav-link">Contact</a></li>
	          
            
	        </ul>
          <div class="collapse navbar-collapse" id="navbarSupportedContent-4">
    <ul class="navbar-nav ml-auto">
      
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" id="navbarDropdownMenuLink-4" data-toggle="dropdown"
          aria-haspopup="true" aria-expanded="false">
          <i class="fas fa-user"></i> Profile </a>
        <div class="dropdown-menu dropdown-menu-right dropdown-info" aria-labelledby="navbarDropdownMenuLink-4">
          <a class="dropdown-item" href="profile.php">My account</a>
          <a class="dropdown-item" href="monthly-sells.php">Monthly Selles</a>
          <a class="dropdown-item" href="asign-industry-profile.php">Asign company</a>
          <a class="dropdown-item" href="index1.php">Chat Box</a>
          <a class="dropdown-item" href="index.php?logout='1'">Log out</a>
        </div>
      </li>
    </ul>
  </div>

	      </div>
	    </div>
	  </nav>
    <!-- END nav -->

    <div class="hero-wrap hero-bread" style="background-image: url('images/product-single.jpg');">
      <div class="container">
        <div class="row no-gutters slider-text align-items-center justify-content-center">
          <div class="col-md-9 ftco-animate text-center">
          	<p class="breadcrumbs"><span class="mr-2"><a href="index.html">Home</a></span> <span class="mr-2"><a href="index.html">Product</a></span> <span>Product Single</span></p>
            <h1 class="mb-0 bread">Product Single</h1>
          </div>
        </div>
      </div>
    </div>

    <section class="ftco-section">
    	<div class="container">
    		<div class="row">
        
    			  <?php $id = $_GET['id'];
 
//selecting data associated with this particular id
$result = mysqli_query($mysqli, "SELECT * FROM shop WHERE id=$id");
 
while($res = mysqli_fetch_array($result))
{
    $name = $res['product_type'];
    $type = $res['product_name'];
    $price = $res['price'];
    $dis = $res['discription'];
    $seller = $res['seller_name'];
    $tell = $res['tell'];
    $adress = $res['adress'];
    $avalabale =$res['quantity'];
    $disc= $res['discount'];
    $newprice = $price-$disc;
    $warenty = $res['warranty_period'];
    $dilivery = $res['diliverry'];
    
 echo' <div class="col-lg-6 mb-5 ftco-animate">';$s=$res['image'];
 echo '<img src="images/'.$s.'" class="img-fluid" style="width:500px;height:470px;">';      
    
    		echo'	</div>';
    		echo'	<div class="col-lg-6 product-details pl-md-5 ftco-animate">';
              
//getting id from url

    echo ' <h2>'; echo $name; echo '</h2>';
    echo '	<h4>'; echo $type; echo '</h4>';
    				
    echo '<p class="price"><span> Price Rs.'; echo $price;echo '</span></p>';
    echo ' <p class="text-dark">Seller name :-'; echo $seller;echo '<p>';
    echo ' <p class="text-dark"><span>'; echo $dis;echo '</p>';
    echo '  <p class="text-dark"><span>Address :-'; echo $adress;echo '</p>';
    echo '  <p class="text-dark"><span>Warrenty Period :-'; echo $warenty;echo '</p>';
    echo '  <p class="text-dark"><span>Dilivery Free :-'; echo $dilivery;echo '</p>';
    echo '  <p class="text-dark"><span>Discount :-'; echo $disc;echo '</p>';
    echo '  <p class="text-warning"><span>Special Offer :-'; echo $newprice;echo '</p>';
    echo ' <p class="text-dark"><span>Telephone no :-'; echo $tell; echo '</p>';
    echo ' <p class="text-dark"><span>Avalability :- '; echo $avalabale; echo '</p>';    
     if($avalabale!=0){
      echo " <form action=\"bill.php?id=$res[id]\" method=\"post\">";
      echo'<div class="row align-items-end">
      <br>
      <div class="w-100"></div>
      <div class="input-group col-md-6 d-flex mb-3">
         <span class="input-group-btn mr-2">
            <button type="button" class="quantity-left-minus btn1"  data-type="minus" data-field="1">
             <i class="ion-ios-remove"></i>
            </button>
          </span>
          <input type="text" id="quantity" class="form-control input-number" value="1" min="1" max="100" color="black" placeholder="" name="qunty1"  required>
          <span class="input-group-btn ml-2">
            <button type="button" class="quantity-right-plus btn1" data-type="plus" data-field="1">
               <i class="ion-ios-add"></i>
           </button>
         </span>
      </div>
            <div class="col-md-6">
              <div class="form-group">';  echo' <input type="hidden" class="form-control" placeholder="" name="price" required value="';echo $newprice;echo'"  readonly >';
                 echo' </div>
               </div> 
               <div class="col-md-6">';
                  echo '<input type="submit" name="cal2" value="Cash On Dilivery" class="btn py-2 px-4 btn-black">
               </div></div>';    
              echo' </form>';
              echo " <form action=\"paypal.php?id=$res[id]\" method=\"post\">";
					    echo'<div class="row align-items-end">
	          		<br>
              <div class="w-100"></div>
							<div class="input-group col-md-6 d-flex mb-3">
	             
	             	 <input type="text" id="quantity" class="form-control input-number" placeholder="add quantity" color="black" placeholder="" name="qunty"  required>
                      
	          	</div>
	              <div class="col-md-6">
	                <div class="form-group">';
	                 echo' <input type="hidden" class="form-control" placeholder="" name="price" required value="';echo $newprice;echo'"  readonly >';
	                 echo' </div>
                </div> <div class="col-md-6">';
                   echo '<input type="submit" name="cal" value="Pay by PAYPAL" class="btn py-2 px-4 btn-black">
               
                </div>' ;    
                  echo' </form>';
              }
              else{
                echo'<h5> <p class="text-danger">Iteam not avalable right now</p></h5>';
              }
               
         }
?>
 
   
    </section>

    <section class="ftco-section">
    	<div class="container">
				<div class="row justify-content-center mb-3 pb-3">
          <div class="col-md-12 heading-section text-center ftco-animate">
          	<span class="subheading">Products</span>
            <h2 class="mb-4">Resent Add Products</h2>
            <p>All Agriculture needs in one place you can biy!!!!!</p>
          </div>
        </div>   		
    	</div>
    
        <?php
        echo'<div style="color:Black;">';echo '<div class="row">';
        //while($res = mysql_fetch_array($result)) { // mysql_fetch_array is deprecated, we need to use mysqli_fetch_array
        while($res = mysqli_fetch_array($result1)) {         
      
    	
           
    		echo'<div class="col-md-6 col-lg-3 ftco-animate">';
    			echo'	<div class="product">';
                        $s=$res['image'];
                        echo '<img src="images/'.$s.'" class="img-fluid" style="width:265px;height:170px;">'; 
    				            echo'	<div class="overlay"></div>
    					          </a>  ';
                        echo'	<div class="text py-3 pb-4 px-3 text-center">';
                        echo'	<h3><a href="#">'; echo '<p>'; echo ""   .$res['product_name']."</br></p>";echo'</a></h3>';
                        echo'<div class="d-flex">';
                  
                        echo'		<div class="pricing">';
                        echo'		<p class="price"><span class="mr-2 ">';echo " <t>"  .$res['price']."<br></h3>";echo'</p>'; echo'</span></p>';
                        echo'		</div>';
                        echo'</div>';
                        echo "<a href=\"product-single.php?id=$res[id]\" class=\"btn btn-primary py-2 px-3\">Buy</a> ";    echo "</h4></p>";    
                    echo'</div> ';
                echo'</div>';
            echo'</div>';
        
       }  echo'</div>'; 
        echo '</div>';
        ?>
    	</div>
    </section>

    <footer class="ftco-footer ftco-section bg-light">
      <div class="container">
      	<div class="row">
      		<div class="mouse">
						<a href="#" class="mouse-icon">
							<div class="mouse-wheel"><span class="ion-ios-arrow-up"></span></div>
						</a>
					</div>
      	</div>
        <div class="row mb-5">
          <div class="col-md">
            <div class="ftco-footer-widget mb-4">
              <h2 class="ftco-heading-2">AgroWeb</h2>
              <p>provide easy commiunication system with planters and industry. both sector can register in this system</p>
              <ul class="ftco-footer-social list-unstyled float-md-left float-lft mt-5">
                <li class="ftco-animate"><a href="www.twitter.com"><span class="icon-twitter"></span></a></li>
                <li class="ftco-animate"><a href="www.facebook.com"><span class="icon-facebook"></span></a></li>
                <li class="ftco-animate"><a href="www.instagram.com"><span class="icon-instagram"></span></a></li>
              </ul>
            </div>
          </div>
          <div class="col-md">
            <div class="ftco-footer-widget mb-4 ml-md-5">
              <h2 class="ftco-heading-2">Menu</h2>
              <ul class="list-unstyled">
                <li><a href="shop.php" class="py-2 d-block">Shop</a></li>
                <li><a href="index1.php" class="py-2 d-block">Online Chat</a></li>
                <li><a href="Blog.php" class="py-2 d-block">Blog</a></li>
                <li><a href="news.php" class="py-2 d-block">News</a></li>
              </ul>
            </div>
          </div>
          <div class="col-md-4">
             <div class="ftco-footer-widget mb-4">
              <h2 class="ftco-heading-2">Catagory</h2>
              <div class="d-flex">
	              <ul class="list-unstyled mr-l-5 pr-l-3 mr-4">
	                <li><a href="Tea-industry.php" class="py-2 d-block">Tea Industry</a></li>
	                <li><a href="rubber-industry.php" class="py-2 d-block">Rubber Industry</a></li>
	                <li><a href="cinnamon-industry.php" class="py-2 d-block">Cinnamon Industry</a></li>
	                <li><a href="solution.php" class="py-2 d-block">Help</a></li>
	              </ul>
	              <ul class="list-unstyled">
	                <li><a href="#" class="py-2 d-block">New Technology</a></li>
	                <li><a href="#" class="py-2 d-block">Contact</a></li>
	              </ul>
	            </div>
            </div>
          </div>
          <div class="col-md">
            <div class="ftco-footer-widget mb-4">
            	<h2 class="ftco-heading-2">Have a Questions?</h2>
            	<div class="block-23 mb-3">
	              <ul>
	                <li><span class="icon icon-map-marker"></span><span class="text">No 11 Polduwa Road, Battaramulla</span></li>
	                <li><a href="#"><span class="icon icon-phone"></span><span class="text">+94 077 924 8860</span></a></li>
	                <li><a href="#"><span class="icon icon-envelope"></span><span class="text">yasiphp@gmail.com</span></a></li>
	              </ul>
	            </div>
            </div>
          </div>
        </div>
        <div class="row">
         
        </div>
      </div>
    </footer>
    
  

  <!-- loader -->
  <div id="ftco-loader" class="show fullscreen"><svg class="circular" width="48px" height="48px"><circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee"/><circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10" stroke="#F96D00"/></svg></div>


  <script src="js/jquery.min.js"></script>
  <script src="js/jquery-migrate-3.0.1.min.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/jquery.easing.1.3.js"></script>
  <script src="js/jquery.waypoints.min.js"></script>
  <script src="js/jquery.stellar.min.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/jquery.magnific-popup.min.js"></script>
  <script src="js/aos.js"></script>
  <script src="js/jquery.animateNumber.min.js"></script>
  <script src="js/bootstrap-datepicker.js"></script>
  <script src="js/scrollax.min.js"></script>
  <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBVWaKrjvy3MaE7SQ74_uJiULgl1JY0H2s&sensor=false"></script>
  <script src="js/google-map.js"></script>
  <script src="js/main.js"></script>

  <script>
		$(document).ready(function(){

		var quantitiy=0;
		   $('.quantity-right-plus').click(function(e){
		        
		        // Stop acting like a button
		        e.preventDefault();
		        // Get the field name
		        var quantity = parseInt($('#quantity').val());
		        
		        // If is not undefined
		            
		            $('#quantity').val(quantity + 1);

		          
		            // Increment
		        
		    });

		     $('.quantity-left-minus').click(function(e){
		        // Stop acting like a button
		        e.preventDefault();
		        // Get the field name
		        var quantity = parseInt($('#quantity').val());
		        
		        // If is not undefined
		      
		            // Increment
		            if(quantity>0){
		            $('#quantity').val(quantity - 1);
		            }
		    });
		    
		});
	</script>
    
  </body>
</html>