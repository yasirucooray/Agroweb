<html>
<head>
    <title>Add Data</title>
</head>

<body>
<?php
//including the database connection file
include_once("config.php");
if(isset($_POST['submit'])) {   
   
    $mname = mysqli_real_escape_string($mysqli, $_POST['mname']);
    $cname = mysqli_real_escape_string($mysqli, $_POST['cname']);
    $month = mysqli_real_escape_string($mysqli, $_POST['month']);
    $sup = mysqli_real_escape_string($mysqli, $_POST['sup']);
    $price = mysqli_real_escape_string($mysqli, $_POST['price']);
    $total = mysqli_real_escape_string($mysqli, $_POST['total']);

    // checking empty fields
    if(empty($mname) || empty($cname) || empty($month)|| empty($sup) || empty($price) || empty($total) ) {
                
        if(empty($mname)) {
            echo "<font color='red'>Name field is empty.</font><br/>";
        }
        
        if(empty($cname)) {
            echo "<font color='red'>last name field is empty.</font><br/>";
        }
        if(empty($month)) {
            echo "<font color='red'>last name field is empty.</font><br/>";
        }
        if(empty($sub)) {
            echo "<font color='red'>saller field is empty.</font><br/>";
        }

        if(empty($price)) {
            echo "<font color='red'>Address field is empty.</font><br/>";
        }

        if(empty($total)) {
            echo "<font color='red'>Quntity field is empty.</font><br/>";
        }


        
        
    } else { 
        // if all the fields are filled (not empty) 
            
        //insert data to database   
        $result = mysqli_query($mysqli, "INSERT INTO sales_details(company_name,member_name,month,quantity,price,total) VALUES('$cname','$mname','$month','$sup','$price','$total')");
      
      
             
        header('location: industry.php');
    }
}
?>
</body>
</html>